export default defineNuxtRouteMiddleware((_to, _from) => {
  // Placeholder: add gating when auth is introduced
  return
})
