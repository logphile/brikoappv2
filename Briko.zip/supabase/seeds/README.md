# Seeds

Optional: add SQL or CSV seeds to quickly populate example projects.
