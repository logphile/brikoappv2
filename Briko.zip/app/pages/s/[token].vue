<template>
  <main class="mx-auto max-w-5xl px-6 py-10 text-white">
    <div v-if="loading" class="opacity-70">Loading…</div>
    <div v-else-if="error" class="text-red-300">{{ error }}</div>
    <template v-else>
      <header class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-semibold">{{ proj?.title }}</h1>
          <p class="text-sm opacity-80">{{ proj?.width }}×{{ proj?.height }} studs · Public view</p>
        </div>
        <div class="flex items-center gap-2">
          <button class="px-3 py-1.5 rounded-xl border border-white/20 hover:border-white/40 text-sm disabled:opacity-50" :disabled="!previewUrl" @click="downloadPreview">Export PNG</button>
          <NuxtLink to="/login" class="px-3 py-1.5 rounded-xl border border-white/20 hover:border-white/40 text-sm">Login to edit</NuxtLink>
        </div>
      </header>

      <section class="mt-6 grid gap-4">
        <figure class="rounded-2xl bg-white/5 ring-1 ring-white/10 p-3 flex items-center justify-center min-h-64">
          <img v-if="previewUrl" :src="previewUrl" alt="Preview" class="max-h-[60vh] rounded-xl" />
          <div v-else class="opacity-70">No preview available</div>
        </figure>

        <div v-if="tiling" class="rounded-2xl bg-white/5 ring-1 ring-white/10 p-4">
          <h2 class="font-medium mb-2">Estimated Cost</h2>
          <div class="text-lg">${{ estTotal.toFixed(2) }}</div>
        </div>
      </section>
    </template>
  </main>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute, useNuxtApp, useHead } from 'nuxt/app'

const route = useRoute()
const { $supabase } = useNuxtApp() as any

const loading = ref(true)
const error = ref('')
const proj = ref<any | null>(null)
const tiling = ref<any | null>(null)
const assets = ref<any[] | null>(null)
const previewUrl = ref('')

// SEO
const absUrl = computed(() => `https://briko.app/s/${String(route.params.token || '')}`)
useHead(() => ({
  title: 'Briko — Public Share',
  meta: [
    { name: 'description', content: 'View a public Briko mosaic or avatar preview and export PNG.' },
    { property: 'og:title', content: 'Briko — Public Share' },
    { property: 'og:description', content: 'View a public Briko mosaic or avatar preview and export PNG.' },
    { property: 'og:url', content: absUrl.value },
    { property: 'og:image', content: previewUrl.value || 'https://briko.app/og-default.png' },
    { name: 'twitter:card', content: 'summary_large_image' },
    { name: 'twitter:title', content: 'Briko — Public Share' },
    { name: 'twitter:description', content: 'View a public Briko mosaic or avatar preview and export PNG.' },
    { name: 'twitter:image', content: previewUrl.value || 'https://briko.app/og-default.png' }
  ]
}))

const estTotal = computed(() => {
  const v = tiling.value?.est_total as any
  if (typeof v === 'number') return v
  if (typeof v === 'string') {
    const n = parseFloat(v)
    return Number.isFinite(n) ? n : 0
  }
  return 0
})

onMounted(async () => {
  loading.value = true
  try {
    const token = String(route.params.token || '')
    const { data, error: err } = await $supabase.rpc('project_public_view', { p_share_token: token })
    if (err) throw err
    const row = Array.isArray(data) ? data[0] : null
    if (!row || !row.project) {
      error.value = 'Project not found or not public.'
    } else {
      proj.value = row.project
      tiling.value = row.tiling
      assets.value = row.assets || []
      // Prefer mosaic preview, fallback to avatar preview
      const list = (assets.value as any[])
      const preview = list.find(a => a.kind === 'preview_png') || list.find(a => a.kind === 'avatar_png')
      if (preview) {
        const { data: urlData } = $supabase.storage.from('public').getPublicUrl(preview.storage_path)
        previewUrl.value = urlData.publicUrl
      }
    }
  } catch (e: any) {
    error.value = e?.message || 'Failed to load project.'
  } finally {
    loading.value = false
  }
})
function downloadPreview(){
  if(!previewUrl.value) return
  const a = document.createElement('a')
  a.href = previewUrl.value
  a.download = 'briko-share.png'
  document.body.appendChild(a)
  a.click()
  a.remove()
}
</script>
