<template>
  <div class="mx-auto max-w-5xl px-4 py-10">
    <h1 class="mb-4 text-2xl font-semibold">Shared Project</h1>
    <p class="text-white/70">Read-only view coming soon.</p>
  </div>
</template>
