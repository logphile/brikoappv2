import { defineNuxtPlugin } from 'nuxt/app'

export default defineNuxtPlugin(() => {
  // Optional: Sentry init later
})
