import { defineNuxtPlugin } from 'nuxt/app'

export default defineNuxtPlugin(() => {
  if (process.dev) return
  // Placeholder for analytics init
})
