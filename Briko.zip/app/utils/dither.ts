export function floydSteinberg(image: ImageData, getNearest: (rgb: [number, number, number]) => [number, number, number]) {
  // Placeholder: no-op dither for now
  return image
}
