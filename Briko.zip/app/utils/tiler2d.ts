export type BomItem = { part_num: string; color: string; count: number }
export function greedyTile(_grid: number[][]): BomItem[] {
  // TODO: implement greedy tiler
  return []
}
