export function mergeVoxels(_grid: number[][][]) {
  // TODO: merge adjacent voxels into cuboids
  return []
}
