<template>
  <div class="min-h-dvh bg-gradient-to-b from-slate-900 to-slate-950 text-white">
    <slot />
  </div>
</template>

<script setup lang="ts">
// Layout wrapper only; global header is mounted in app/app.vue
</script>
