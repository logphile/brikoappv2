<template>
  <div class="rounded-2xl bg-brand-card p-4 shadow-sm ring-1 ring-white/5">
    <slot />
  </div>
</template>
