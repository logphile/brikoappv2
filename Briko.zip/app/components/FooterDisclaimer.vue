<template>
  <footer class="bg-[#0B1220]">
    <div class="mx-auto max-w-7xl px-6">
      <hr class="mt-12 mb-6 border-white/10" />
      <p class="pb-10 text-center text-xs sm:text-[13px] leading-relaxed text-gray-400">
        Briko is an independent tool — not affiliated with, endorsed by, or associated with the LEGO® Group.
        <span class="block sm:inline"> LEGO® is a trademark of the LEGO Group of companies.</span>
      </p>
    </div>
  </footer>
</template>
