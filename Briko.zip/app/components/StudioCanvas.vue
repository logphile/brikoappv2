<template>
  <AppCard>
    <div class="grid h-[420px] place-items-center text-white/70">
      <span>Canvas preview coming soon</span>
    </div>
  </AppCard>
</template>
