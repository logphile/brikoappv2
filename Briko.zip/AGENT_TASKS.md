# Agent Tasks (source of truth)

## Queue
- [ ] (example) Kickoff task — describe it or use Issues with the "windsurf" label to enqueue automatically.

## Done
