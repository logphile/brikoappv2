
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T extends DefineComponent> = T & DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>>
type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = (T & DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }>)
interface _GlobalComponents {
      'AppFooter': typeof import("../app/components/AppFooter.vue")['default']
    'AppHeader': typeof import("../app/components/AppHeader.vue")['default']
    'BottomBeforeAfter': typeof import("../app/components/BottomBeforeAfter.vue")['default']
    'CommunityGrid': typeof import("../app/components/CommunityGrid.vue")['default']
    'ConsentBanner': typeof import("../app/components/ConsentBanner.vue")['default']
    'FeatureBites': typeof import("../app/components/FeatureBites.vue")['default']
    'FeatureList': typeof import("../app/components/FeatureList.vue")['default']
    'FooterDisclaimer': typeof import("../app/components/FooterDisclaimer.vue")['default']
    'HeroDemo': typeof import("../app/components/HeroDemo.client.vue")['default']
    'HeroSection': typeof import("../app/components/HeroSection.vue")['default']
    'HowItWorksSection': typeof import("../app/components/HowItWorksSection.vue")['default']
    'InfoTip': typeof import("../app/components/InfoTip.vue")['default']
    'InlineStats': typeof import("../app/components/InlineStats.vue")['default']
    'LayerSlider': typeof import("../app/components/LayerSlider.client.vue")['default']
    'MosaicCanvas': typeof import("../app/components/MosaicCanvas.client.vue")['default']
    'MosaicUploader': typeof import("../app/components/MosaicUploader.client.vue")['default']
    'ProjectCard': typeof import("../app/components/ProjectCard.vue")['default']
    'RegeneratingChip': typeof import("../app/components/RegeneratingChip.vue")['default']
    'StepBadge': typeof import("../app/components/StepBadge.vue")['default']
    'StepCanvas': typeof import("../app/components/StepCanvas.client.vue")['default']
    'StepChips': typeof import("../app/components/StepChips.vue")['default']
    'StudioCanvas': typeof import("../app/components/StudioCanvas.vue")['default']
    'StudioControls': typeof import("../app/components/StudioControls.vue")['default']
    'StudioStats': typeof import("../app/components/StudioStats.vue")['default']
    'ToastHost': typeof import("../app/components/ToastHost.client.vue")['default']
    'VoxelPreview': typeof import("../app/components/VoxelPreview.client.vue")['default']
    'VoxelViewer': typeof import("../app/components/VoxelViewer.client.vue")['default']
    'GalleryGrid': typeof import("../app/components/gallery/GalleryGrid.vue")['default']
    'GalleryProjectCard': typeof import("../app/components/gallery/ProjectCard.vue")['default']
    'TagsTagPicker': typeof import("../app/components/tags/TagPicker.vue")['default']
    'UiAppButton': typeof import("../app/components/ui/AppButton.vue")['default']
    'UiAppCard': typeof import("../app/components/ui/AppCard.vue")['default']
    'UiAppInput': typeof import("../app/components/ui/AppInput.vue")['default']
    'UiAppTabs': typeof import("../app/components/ui/AppTabs.vue")['default']
    'UiNavBar': typeof import("../app/components/ui/NavBar.client.vue")['default']
    'NuxtWelcome': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/welcome.vue")['default']
    'NuxtLayout': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-layout")['default']
    'NuxtErrorBoundary': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
    'ClientOnly': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/client-only")['default']
    'DevOnly': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/dev-only")['default']
    'ServerPlaceholder': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'NuxtLink': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-link")['default']
    'NuxtLoadingIndicator': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
    'NuxtTime': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
    'NuxtRouteAnnouncer': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
    'NuxtImg': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
    'NuxtPicture': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
    'NuxtPage': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/pages/runtime/page")['default']
    'NoScript': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['NoScript']
    'Link': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Link']
    'Base': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Base']
    'Title': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Title']
    'Meta': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Meta']
    'Style': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Style']
    'Head': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Head']
    'Html': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Html']
    'Body': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Body']
    'NuxtIsland': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-island")['default']
    'HeroDemo': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'LayerSlider': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'MosaicCanvas': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'MosaicUploader': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'StepCanvas': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'ToastHost': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'VoxelPreview': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'VoxelViewer': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'UiNavBar': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'NuxtRouteAnnouncer': typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
      'LazyAppFooter': LazyComponent<typeof import("../app/components/AppFooter.vue")['default']>
    'LazyAppHeader': LazyComponent<typeof import("../app/components/AppHeader.vue")['default']>
    'LazyBottomBeforeAfter': LazyComponent<typeof import("../app/components/BottomBeforeAfter.vue")['default']>
    'LazyCommunityGrid': LazyComponent<typeof import("../app/components/CommunityGrid.vue")['default']>
    'LazyConsentBanner': LazyComponent<typeof import("../app/components/ConsentBanner.vue")['default']>
    'LazyFeatureBites': LazyComponent<typeof import("../app/components/FeatureBites.vue")['default']>
    'LazyFeatureList': LazyComponent<typeof import("../app/components/FeatureList.vue")['default']>
    'LazyFooterDisclaimer': LazyComponent<typeof import("../app/components/FooterDisclaimer.vue")['default']>
    'LazyHeroDemo': LazyComponent<typeof import("../app/components/HeroDemo.client.vue")['default']>
    'LazyHeroSection': LazyComponent<typeof import("../app/components/HeroSection.vue")['default']>
    'LazyHowItWorksSection': LazyComponent<typeof import("../app/components/HowItWorksSection.vue")['default']>
    'LazyInfoTip': LazyComponent<typeof import("../app/components/InfoTip.vue")['default']>
    'LazyInlineStats': LazyComponent<typeof import("../app/components/InlineStats.vue")['default']>
    'LazyLayerSlider': LazyComponent<typeof import("../app/components/LayerSlider.client.vue")['default']>
    'LazyMosaicCanvas': LazyComponent<typeof import("../app/components/MosaicCanvas.client.vue")['default']>
    'LazyMosaicUploader': LazyComponent<typeof import("../app/components/MosaicUploader.client.vue")['default']>
    'LazyProjectCard': LazyComponent<typeof import("../app/components/ProjectCard.vue")['default']>
    'LazyRegeneratingChip': LazyComponent<typeof import("../app/components/RegeneratingChip.vue")['default']>
    'LazyStepBadge': LazyComponent<typeof import("../app/components/StepBadge.vue")['default']>
    'LazyStepCanvas': LazyComponent<typeof import("../app/components/StepCanvas.client.vue")['default']>
    'LazyStepChips': LazyComponent<typeof import("../app/components/StepChips.vue")['default']>
    'LazyStudioCanvas': LazyComponent<typeof import("../app/components/StudioCanvas.vue")['default']>
    'LazyStudioControls': LazyComponent<typeof import("../app/components/StudioControls.vue")['default']>
    'LazyStudioStats': LazyComponent<typeof import("../app/components/StudioStats.vue")['default']>
    'LazyToastHost': LazyComponent<typeof import("../app/components/ToastHost.client.vue")['default']>
    'LazyVoxelPreview': LazyComponent<typeof import("../app/components/VoxelPreview.client.vue")['default']>
    'LazyVoxelViewer': LazyComponent<typeof import("../app/components/VoxelViewer.client.vue")['default']>
    'LazyGalleryGrid': LazyComponent<typeof import("../app/components/gallery/GalleryGrid.vue")['default']>
    'LazyGalleryProjectCard': LazyComponent<typeof import("../app/components/gallery/ProjectCard.vue")['default']>
    'LazyTagsTagPicker': LazyComponent<typeof import("../app/components/tags/TagPicker.vue")['default']>
    'LazyUiAppButton': LazyComponent<typeof import("../app/components/ui/AppButton.vue")['default']>
    'LazyUiAppCard': LazyComponent<typeof import("../app/components/ui/AppCard.vue")['default']>
    'LazyUiAppInput': LazyComponent<typeof import("../app/components/ui/AppInput.vue")['default']>
    'LazyUiAppTabs': LazyComponent<typeof import("../app/components/ui/AppTabs.vue")['default']>
    'LazyUiNavBar': LazyComponent<typeof import("../app/components/ui/NavBar.client.vue")['default']>
    'LazyNuxtWelcome': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/welcome.vue")['default']>
    'LazyNuxtLayout': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
    'LazyNuxtErrorBoundary': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
    'LazyClientOnly': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/client-only")['default']>
    'LazyDevOnly': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/dev-only")['default']>
    'LazyServerPlaceholder': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyNuxtLink': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-link")['default']>
    'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
    'LazyNuxtTime': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
    'LazyNuxtImg': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
    'LazyNuxtPicture': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
    'LazyNuxtPage': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/pages/runtime/page")['default']>
    'LazyNoScript': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['NoScript']>
    'LazyLink': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Link']>
    'LazyBase': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Base']>
    'LazyTitle': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Title']>
    'LazyMeta': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Meta']>
    'LazyStyle': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Style']>
    'LazyHead': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Head']>
    'LazyHtml': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Html']>
    'LazyBody': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Body']>
    'LazyNuxtIsland': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-island")['default']>
    'LazyHeroDemo': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyLayerSlider': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyMosaicCanvas': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyMosaicUploader': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyStepCanvas': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyToastHost': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyVoxelPreview': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyVoxelViewer': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyUiNavBar': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export const AppFooter: typeof import("../app/components/AppFooter.vue")['default']
export const AppHeader: typeof import("../app/components/AppHeader.vue")['default']
export const BottomBeforeAfter: typeof import("../app/components/BottomBeforeAfter.vue")['default']
export const CommunityGrid: typeof import("../app/components/CommunityGrid.vue")['default']
export const ConsentBanner: typeof import("../app/components/ConsentBanner.vue")['default']
export const FeatureBites: typeof import("../app/components/FeatureBites.vue")['default']
export const FeatureList: typeof import("../app/components/FeatureList.vue")['default']
export const FooterDisclaimer: typeof import("../app/components/FooterDisclaimer.vue")['default']
export const HeroDemo: typeof import("../app/components/HeroDemo.client.vue")['default']
export const HeroSection: typeof import("../app/components/HeroSection.vue")['default']
export const HowItWorksSection: typeof import("../app/components/HowItWorksSection.vue")['default']
export const InfoTip: typeof import("../app/components/InfoTip.vue")['default']
export const InlineStats: typeof import("../app/components/InlineStats.vue")['default']
export const LayerSlider: typeof import("../app/components/LayerSlider.client.vue")['default']
export const MosaicCanvas: typeof import("../app/components/MosaicCanvas.client.vue")['default']
export const MosaicUploader: typeof import("../app/components/MosaicUploader.client.vue")['default']
export const ProjectCard: typeof import("../app/components/ProjectCard.vue")['default']
export const RegeneratingChip: typeof import("../app/components/RegeneratingChip.vue")['default']
export const StepBadge: typeof import("../app/components/StepBadge.vue")['default']
export const StepCanvas: typeof import("../app/components/StepCanvas.client.vue")['default']
export const StepChips: typeof import("../app/components/StepChips.vue")['default']
export const StudioCanvas: typeof import("../app/components/StudioCanvas.vue")['default']
export const StudioControls: typeof import("../app/components/StudioControls.vue")['default']
export const StudioStats: typeof import("../app/components/StudioStats.vue")['default']
export const ToastHost: typeof import("../app/components/ToastHost.client.vue")['default']
export const VoxelPreview: typeof import("../app/components/VoxelPreview.client.vue")['default']
export const VoxelViewer: typeof import("../app/components/VoxelViewer.client.vue")['default']
export const GalleryGrid: typeof import("../app/components/gallery/GalleryGrid.vue")['default']
export const GalleryProjectCard: typeof import("../app/components/gallery/ProjectCard.vue")['default']
export const TagsTagPicker: typeof import("../app/components/tags/TagPicker.vue")['default']
export const UiAppButton: typeof import("../app/components/ui/AppButton.vue")['default']
export const UiAppCard: typeof import("../app/components/ui/AppCard.vue")['default']
export const UiAppInput: typeof import("../app/components/ui/AppInput.vue")['default']
export const UiAppTabs: typeof import("../app/components/ui/AppTabs.vue")['default']
export const UiNavBar: typeof import("../app/components/ui/NavBar.client.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
export const NuxtPicture: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const NuxtPage: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const HeroDemo: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const LayerSlider: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const MosaicCanvas: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const MosaicUploader: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const StepCanvas: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const ToastHost: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const VoxelPreview: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const VoxelViewer: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const UiNavBar: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const LazyAppFooter: LazyComponent<typeof import("../app/components/AppFooter.vue")['default']>
export const LazyAppHeader: LazyComponent<typeof import("../app/components/AppHeader.vue")['default']>
export const LazyBottomBeforeAfter: LazyComponent<typeof import("../app/components/BottomBeforeAfter.vue")['default']>
export const LazyCommunityGrid: LazyComponent<typeof import("../app/components/CommunityGrid.vue")['default']>
export const LazyConsentBanner: LazyComponent<typeof import("../app/components/ConsentBanner.vue")['default']>
export const LazyFeatureBites: LazyComponent<typeof import("../app/components/FeatureBites.vue")['default']>
export const LazyFeatureList: LazyComponent<typeof import("../app/components/FeatureList.vue")['default']>
export const LazyFooterDisclaimer: LazyComponent<typeof import("../app/components/FooterDisclaimer.vue")['default']>
export const LazyHeroDemo: LazyComponent<typeof import("../app/components/HeroDemo.client.vue")['default']>
export const LazyHeroSection: LazyComponent<typeof import("../app/components/HeroSection.vue")['default']>
export const LazyHowItWorksSection: LazyComponent<typeof import("../app/components/HowItWorksSection.vue")['default']>
export const LazyInfoTip: LazyComponent<typeof import("../app/components/InfoTip.vue")['default']>
export const LazyInlineStats: LazyComponent<typeof import("../app/components/InlineStats.vue")['default']>
export const LazyLayerSlider: LazyComponent<typeof import("../app/components/LayerSlider.client.vue")['default']>
export const LazyMosaicCanvas: LazyComponent<typeof import("../app/components/MosaicCanvas.client.vue")['default']>
export const LazyMosaicUploader: LazyComponent<typeof import("../app/components/MosaicUploader.client.vue")['default']>
export const LazyProjectCard: LazyComponent<typeof import("../app/components/ProjectCard.vue")['default']>
export const LazyRegeneratingChip: LazyComponent<typeof import("../app/components/RegeneratingChip.vue")['default']>
export const LazyStepBadge: LazyComponent<typeof import("../app/components/StepBadge.vue")['default']>
export const LazyStepCanvas: LazyComponent<typeof import("../app/components/StepCanvas.client.vue")['default']>
export const LazyStepChips: LazyComponent<typeof import("../app/components/StepChips.vue")['default']>
export const LazyStudioCanvas: LazyComponent<typeof import("../app/components/StudioCanvas.vue")['default']>
export const LazyStudioControls: LazyComponent<typeof import("../app/components/StudioControls.vue")['default']>
export const LazyStudioStats: LazyComponent<typeof import("../app/components/StudioStats.vue")['default']>
export const LazyToastHost: LazyComponent<typeof import("../app/components/ToastHost.client.vue")['default']>
export const LazyVoxelPreview: LazyComponent<typeof import("../app/components/VoxelPreview.client.vue")['default']>
export const LazyVoxelViewer: LazyComponent<typeof import("../app/components/VoxelViewer.client.vue")['default']>
export const LazyGalleryGrid: LazyComponent<typeof import("../app/components/gallery/GalleryGrid.vue")['default']>
export const LazyGalleryProjectCard: LazyComponent<typeof import("../app/components/gallery/ProjectCard.vue")['default']>
export const LazyTagsTagPicker: LazyComponent<typeof import("../app/components/tags/TagPicker.vue")['default']>
export const LazyUiAppButton: LazyComponent<typeof import("../app/components/ui/AppButton.vue")['default']>
export const LazyUiAppCard: LazyComponent<typeof import("../app/components/ui/AppCard.vue")['default']>
export const LazyUiAppInput: LazyComponent<typeof import("../app/components/ui/AppInput.vue")['default']>
export const LazyUiAppTabs: LazyComponent<typeof import("../app/components/ui/AppTabs.vue")['default']>
export const LazyUiNavBar: LazyComponent<typeof import("../app/components/ui/NavBar.client.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/nuxt-island")['default']>
export const LazyHeroDemo: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyLayerSlider: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyMosaicCanvas: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyMosaicUploader: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyStepCanvas: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyToastHost: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyVoxelPreview: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyVoxelViewer: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyUiNavBar: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@3.18.1_@netlify+blobs@_f0cd9ef34a3772c6e63311e55e6b8558/node_modules/nuxt/dist/app/components/server-placeholder")['default']>

export const componentNames: string[]
