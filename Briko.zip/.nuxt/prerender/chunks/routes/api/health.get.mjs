import { defineEventHandler } from 'file://H:/BrickMOC/Briko/node_modules/h3/dist/index.mjs';

const health_get = defineEventHandler(() => {
  return { status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() };
});

export { health_get as default };
//# sourceMappingURL=health.get.mjs.map
