# Samples

Place bright demo images here for the 3D Builder to auto-load on first visit.

- Expected file: `parrot-32.png` (32×32). The app will try `/samples/parrot-32.png` first, then fallback to `/demo-original.jpg`.
- You can replace it with any colorful 32×32 image to showcase palette mapping.
