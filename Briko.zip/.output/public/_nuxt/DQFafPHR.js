function r(e){return new Worker(""+new URL("greedyTiler-CYnemCv0.js",import.meta.url).href,{type:"module",name:e?.name})}export{r as default};
