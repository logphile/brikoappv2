function r(e){return new Worker(""+new URL("mosaic.worker-G6V6MZ04.js",import.meta.url).href,{type:"module",name:e?.name})}export{r as default};
